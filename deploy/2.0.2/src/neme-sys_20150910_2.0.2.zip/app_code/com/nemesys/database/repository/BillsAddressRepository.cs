using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using com.nemesys.model;
using com.nemesys.database;
using NHibernate;
using NHibernate.Criterion;
using System.Web;
using System.Security.Cryptography;
using System.Text;
using System.Web.Caching;

namespace com.nemesys.database.repository
{
	public class BillsAddressRepository : IBillsAddressRepository
	{		
		public void insert(BillsAddress billsAddress)
		{
			using (ISession session = NHibernateHelper.getCurrentSession())
			using (ITransaction tx = session.BeginTransaction())
			{				
				session.Save(billsAddress);				
				tx.Commit();
				NHibernateHelper.closeSession();
			}
		}
		
		public void update(BillsAddress billsAddress)
		{
			using (ISession session = NHibernateHelper.getCurrentSession())
			using (ITransaction tx = session.BeginTransaction())
			{				
				session.Update(billsAddress);				
				tx.Commit();
				NHibernateHelper.closeSession();
			}
			
			//rimuovo cache		
			IDictionaryEnumerator CacheEnum = HttpContext.Current.Cache.GetEnumerator();
			while (CacheEnum.MoveNext())
			{		  
				string cacheKey = HttpContext.Current.Server.HtmlEncode(CacheEnum.Key.ToString()); 
				if(cacheKey.Contains("bills-address-"+billsAddress.id))
				{ 
					HttpContext.Current.Cache.Remove(cacheKey);
				}
			}	
		}
		
		public void delete(BillsAddress billsAddress)
		{
			using (ISession session = NHibernateHelper.getCurrentSession())
			using (ITransaction tx = session.BeginTransaction())
			{		
				session.Delete(billsAddress);	
				tx.Commit();
				NHibernateHelper.closeSession();
			}
			
			//rimuovo cache		
			IDictionaryEnumerator CacheEnum = HttpContext.Current.Cache.GetEnumerator();
			while (CacheEnum.MoveNext())
			{		  
				string cacheKey = HttpContext.Current.Server.HtmlEncode(CacheEnum.Key.ToString()); 
				if(cacheKey.Contains("bills-address-"+billsAddress.id))
				{ 
					HttpContext.Current.Cache.Remove(cacheKey);
				}
			}					
		}
		
		public BillsAddress getById(int id)
		{
			return getByIdCached(id, false);
		}
		
		public BillsAddress getByIdCached(int id, bool cached)
		{
			BillsAddress billsAddress = null;	
			
			if(cached)
			{
				billsAddress = (BillsAddress)HttpContext.Current.Cache.Get("bills-address-"+id);
				if(billsAddress != null){
					return billsAddress;
				}
			}
							
			using (ISession session = NHibernateHelper.getCurrentSession())
			{				
				billsAddress = session.Get<BillsAddress>(id);	
				NHibernateHelper.closeSession();
			}

			if(cached)
			{
				if(billsAddress == null){
					billsAddress = new BillsAddress();
					billsAddress.id=-1;
				}
				HttpContext.Current.Cache.Insert("bills-address-"+billsAddress.id, billsAddress, null, DateTime.Now.AddHours(24), System.Web.Caching.Cache.NoSlidingExpiration, CacheItemPriority.High, null);
			}
			
			return billsAddress;
		}
		
		public BillsAddress getByUserId(int userId)
		{
			return getByUserIdCached(userId, false);
		}
		
		public BillsAddress getByUserIdCached(int userId, bool cached)
		{
			BillsAddress billsAddress = null;	
			
			if(cached)
			{
				billsAddress = (BillsAddress)HttpContext.Current.Cache.Get("bills-address-"+userId);
				if(billsAddress != null){
					return billsAddress;
				}
			}
							
			using (ISession session = NHibernateHelper.getCurrentSession())
			{				
				billsAddress = session.CreateQuery("from BillsAddress where idUser=:idUser").SetInt32("idUser",userId).UniqueResult<BillsAddress>();	
				NHibernateHelper.closeSession();
			}

			if(cached)
			{
				if(billsAddress == null){
					billsAddress = new BillsAddress();
					billsAddress.id=-1;
					billsAddress.idUser=userId;
				}
				HttpContext.Current.Cache.Insert("bills-address-"+billsAddress.idUser, billsAddress, null, DateTime.Now.AddHours(24), System.Web.Caching.Cache.NoSlidingExpiration, CacheItemPriority.High, null);
			}
			
			return billsAddress;
		}	
		

		//************ MANAGE ORDER BILLS ADDRESS  ************
		public void insertOrderBillsAddress(OrderBillsAddress orderBillsAddress)
		{
			using (ISession session = NHibernateHelper.getCurrentSession())
			using (ITransaction tx = session.BeginTransaction())
			{				
				session.Save(orderBillsAddress);				
				tx.Commit();
				NHibernateHelper.closeSession();
			}
		}
		
		public void updateOrderBillsAddress(OrderBillsAddress orderBillsAddress)
		{
			using (ISession session = NHibernateHelper.getCurrentSession())
			using (ITransaction tx = session.BeginTransaction())
			{				
				session.Update(orderBillsAddress);				
				tx.Commit();
				NHibernateHelper.closeSession();
			}
			
			//rimuovo cache		
			IDictionaryEnumerator CacheEnum = HttpContext.Current.Cache.GetEnumerator();
			while (CacheEnum.MoveNext())
			{		  
				string cacheKey = HttpContext.Current.Server.HtmlEncode(CacheEnum.Key.ToString()); 
				if(cacheKey.Contains("order-bills-address-"+orderBillsAddress.idOrder))
				{ 
					HttpContext.Current.Cache.Remove(cacheKey);
				}
			}	
		}
		
		public void deleteOrderBillsAddress(OrderBillsAddress orderBillsAddress)
		{
			using (ISession session = NHibernateHelper.getCurrentSession())
			using (ITransaction tx = session.BeginTransaction())
			{		
				session.Delete(orderBillsAddress);	
				tx.Commit();
				NHibernateHelper.closeSession();
			}
			
			//rimuovo cache		
			IDictionaryEnumerator CacheEnum = HttpContext.Current.Cache.GetEnumerator();
			while (CacheEnum.MoveNext())
			{		  
				string cacheKey = HttpContext.Current.Server.HtmlEncode(CacheEnum.Key.ToString()); 
				if(cacheKey.Contains("order-bills-address-"+orderBillsAddress.idOrder))
				{ 
					HttpContext.Current.Cache.Remove(cacheKey);
				}
			}					
		}
		
		public OrderBillsAddress getOrderBillsAddress(int orderId)
		{
			return getOrderBillsAddressCached(orderId, false);
		}
		
		public OrderBillsAddress getOrderBillsAddressCached(int orderId, bool cached)
		{
			OrderBillsAddress orderBillsAddress = null;	
			
			if(cached)
			{
				orderBillsAddress = (OrderBillsAddress)HttpContext.Current.Cache.Get("order-bills-address-"+orderId);
				if(orderBillsAddress != null){
					return orderBillsAddress;
				}
			}
							
			using (ISession session = NHibernateHelper.getCurrentSession())
			{				
				orderBillsAddress = session.CreateQuery("from OrderBillsAddress where idOrder=:idOrder").SetInt32("idOrder",orderId).UniqueResult<OrderBillsAddress>();	
				NHibernateHelper.closeSession();
			}

			if(cached)
			{
				if(orderBillsAddress == null){
					orderBillsAddress = new OrderBillsAddress();
					orderBillsAddress.idBills=-1;
					orderBillsAddress.idOrder=orderId;
				}
				HttpContext.Current.Cache.Insert("order-bills-address-"+orderBillsAddress.idOrder, orderBillsAddress, null, DateTime.Now.AddHours(24), System.Web.Caching.Cache.NoSlidingExpiration, CacheItemPriority.High, null);
			}
			
			return orderBillsAddress;
		}
	}
}