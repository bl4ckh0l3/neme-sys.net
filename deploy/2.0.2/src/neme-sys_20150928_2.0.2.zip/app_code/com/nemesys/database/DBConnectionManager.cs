using System;
using System.Data;
using MySql.Data.MySqlClient;

namespace com.nemesys.database
{
	public class DBConnectionManager
	{
		private static string connectionString = "";

		public static MySqlConnection getDBConnection()
		{
			MySqlConnection connection = null;
			try
			{			
				connection = new MySqlConnection();
				connection.ConnectionString = connectionString;
				connection.Open();
			}
			    catch (Exception ex)
			{
				throw new Exception("Connection string was not set incorrectly: " + ex.Message);
			}
				
			return connection;
		}

		public static string getConnectionString()
		{
			return connectionString;
		}

		public static void setConnectionString(string newConnString)
		{
			connectionString = newConnString;
		}
	}
}