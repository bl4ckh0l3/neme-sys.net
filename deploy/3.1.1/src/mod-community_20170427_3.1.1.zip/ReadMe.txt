Istallazione
=============
Per istallare correttamente il modulo sul vostro sistema, eseguire i seguenti passaggi:

1) caricare sul vostro server, o sul vostro pc locale, nella directory designata per la vostra applicazione web, tutti i file estratti dallo zip di istallazione (sovrascrivendo tutti i file gi� presenti);
2) aprire il browser all'url: http://www.vostro_sito.com/public/install/moduleinstall.aspx (se lavorate sul vostro pc locale, sostituire www.vostro_sito.com con localhost)
3) al termine dell'istallazione sarete inviati direttamente al BackOffice;
4) Tutte le nuove funzionalit� del modulo saranno attive;

l'utente amministratore di default �:
user: administrator
pwd: admin


--
Il team neme-sys
www.neme-sys.it


********************************************************************************************************************************************************
********************************************************************************************************************************************************


Installations
=============
To install neme-sys module on your system, perform the following steps:

1) load on your server, or on your local PC, under the directory designated for your web application, all files and directories extracted from the installation .zip (overriding every file already present);
2) Open the browser at the URL: http://www.your_site.com/public/install/moduleinstall.aspx (if you work on your local computer, replace www.your_site.com with localhost)
3) After installation you will be sent directly to BackOffice;
4) All features will be active;

default administrator user is:
user: administrator
pwd: admin

 
--
Your neme-sys-team
www.neme-sys.com
