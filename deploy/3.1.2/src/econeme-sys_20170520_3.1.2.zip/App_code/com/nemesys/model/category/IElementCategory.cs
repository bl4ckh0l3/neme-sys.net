using System;
using System.Text;

namespace com.nemesys.model
{
	public interface IElementCategory
	{	
		int idParent {get;set;}

		int idCategory {get;set;}
	}
}