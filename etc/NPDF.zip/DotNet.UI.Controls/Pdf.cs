# region NameSpaces 
using System; 
using System.Data; 
using System.IO; 
using System.Web; 
using System.Web.UI; 
using System.Web.UI.WebControls; 
using System.Web.SessionState; 
using System.ComponentModel; 
using System.Collections; 
# endregion NameSpaces 

namespace DotNet.UI.Controls
{ 
	# region PDF Server Control
	/// <summary> 
	/// PDF Server Control 
	/// </summary> 
	[DefaultProperty("Text"), 
	ToolboxData("<{0}:Pdf runat=server></{0}:Pdf>")] 
	public class Pdf : System.Web.UI.Page
	{
		# region Custom Declarations
		byte[] foAsBytes;
		byte[] stringFoBytes;
		DotNet.UI.Controls.XslFO dotNetFop;
		HttpContext ctx; // = HttpContext.Current; 

		private DataTable reportDataSource; 
		private DataTable reportTableInfo; 

		private string reportTitle; 
		private string reportTitleSize; 
		private string reportColumnTextSize; 

		private string reportLogoURL; 
		private string reportLogoHeight; 
		private string reportLogoWidth; 

		private string reportID; 
		private string reportUserID; 
		private string reportRunDate; 
		private string reportFoFilePath; 
		private string reportTextSize; 
		private string reportPageWidth; 
		private string reportPageHeight; 
		private string reportPageFormat = "P"; 
		private string reportPageNoTitle; 
		private string reportRunDateTitle; 
		private string reportIDTitle; 
		private string reportUserIDTitle; 

		# endregion Custom Declarations 

		# region Public Properties 
		/// <summary> 
		/// set or get 
		/// 1. Bind a DataTable instance with Data for 'ReportDataSource' Property 
		/// 2. Add all the Display Column Names for 'ColumnName' Property in a new 'DataTable' 
		/// 3. Add Display Column's Width as 0'th Row in the same 'DataTable' 
		/// 4. Bind the DataTable instance for 'ReportTableInfo' Property 
		/// 5. Column Count for the DataTable bound for 'ReportDataSource' and 'ReportTableInfo' should be same 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public DataTable ReportDataSource 
		{ 
			get 
			{ 
				return reportDataSource; 
			} 

			set 
			{ 
				reportDataSource = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// 1. Add all the Display Column Names for 'ColumnName' Property in a new 'DataTable' 
		/// 2. Add Display Column's Width as 0'th Row in the same 'DataTable' 
		/// 3. Bind the DataTable instance for 'ReportTableInfo' Property 
		/// 4. Column Count for the DataTable bound for 'ReportDataSource' and 'ReportTableInfo' should be same 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public DataTable ReportTableInfo 
		{ 
			get 
			{ 
				return reportTableInfo; 
			} 

			set 
			{ 
				reportTableInfo = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// Report Column Data Font Size. [Default : 8pt] 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportTextSize 
		{ 
			get 
			{ 
				if (null == reportTextSize) 
				{ 
					reportTextSize = "8pt"; 
				} 

				return reportTextSize; 
			} 

			set 
			{ 
				reportTextSize = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// Report Column Title Font Size. [Default : 8pt] 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportColumnTextSize 
		{ 
			get 
			{ 
				if (null == reportColumnTextSize) 
				{ 
					reportColumnTextSize = "8pt"; 
				} 

				return reportColumnTextSize; 
			} 

			set 
			{ 
				reportColumnTextSize = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// Report Title 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportTitle 
		{ 
			get 
			{ 
				return reportTitle; 
			} 

			set 
			{ 
				reportTitle = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// Report Title Font Size. [Default : 14pt] 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportTitleSize 
		{ 
			get 
			{ 
				if (null == reportTitleSize) 
				{ 
					reportTitleSize = "14pt"; 
				} 
				return reportTitleSize; 
			} 

			set 
			{ 
				reportTitleSize = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// Report ID / Report WebForm Name 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportID 
		{ 
			get 
			{ 
				return reportID; 
			} 

			set 
			{ 
				reportID = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// Report User ID / Login User ID 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportUserID 
		{ 
			get 
			{ 
				return reportUserID; 
			} 

			set 
			{ 
				reportUserID = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// Report Run Date. [Default : System.DateTime.Now - WebServer Current Date Time] 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportRunDate 
		{ 
			get 
			{ 
				if (null == reportRunDate) 
				{ 
					reportRunDate = System.DateTime.Now.ToString();
				} 

				return reportRunDate; 
			} 

			set 
			{ 
				reportRunDate = value; 
			} 
		} 

		/// <summary> 
		/// get 
		/// Report FO File Path. [Default : Current WebApplication Root Folder] 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportFoFilePath 
		{ 
			get 
			{
				try
				{
					if (null == reportFoFilePath) 
					{ 
						Random rdm1 = new Random(unchecked((int)DateTime.Now.Ticks)); 

						reportFoFilePath = ctx.Server.MapPath(".") + "\\FoTemp\\" + rdm1.Next() + ".fo"; 
					}
				}
				catch (Exception ex)
				{
					reportFoFilePath = ex.Message;
				}

				return reportFoFilePath; 
			} 
			/*
				set 
				{ 
					reportFoFilePath = value; 
				}
			*/
		} 

		/// <summary> 
		/// set or get 
		/// Report Logo URL in the form 'http://localhost/DotNetPdf/images/DotNet.jpg'
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportLogoURL 
		{ 
			get 
			{ 
				return reportLogoURL; 
			} 

			set 
			{ 
				reportLogoURL = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// Report Logo Image Width.
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportLogoWidth 
		{ 
			get 
			{ 
				return reportLogoWidth; 
			} 

			set 
			{ 
				reportLogoWidth = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// Report Logo Image Height.
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportLogoHeight 
		{ 
			get 
			{ 
				return reportLogoHeight; 
			} 

			set 
			{ 
				reportLogoHeight = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// "P" for Portrait / "L" for Landscape. [Default : P] 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportPageFormat 
		{ 
			get 
			{ 
				return reportPageFormat; 
			} 

			set 
			{ 
				reportPageFormat = value; 
			} 
		} 

		/// <summary> 
		/// Private Property 
		/// Report Page Width. [Default : 21cm / Portrait A4 Size Page Width] 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(false)] 
		private string ReportPageWidth 
		{ 
			get 
			{ 
				if (null == reportPageWidth) 
				{ 
					reportPageWidth = "21cm"; 
				} 
				return reportPageWidth; 
			} 

			set 
			{ 
				reportPageWidth = value; 
			} 
		} 

		/// <summary> 
		/// Private Property 
		/// Report Page Height. [Default : 29.7cm / Portrait A4 Size Page Height] 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(false)] 
		private string ReportPageHeight 
		{ 
			get 
			{ 
				if (null == reportPageHeight) 
				{ 
					reportPageHeight = "29.7cm"; 
				} 
				return reportPageHeight; 
			} 

			set 
			{ 
				reportPageHeight = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// Report Page Title for 'ReportUserID' Property. [Default : User] 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportUserIDTitle 
		{ 
			get 
			{ 
				if (null == reportUserIDTitle) 
				{ 
					reportUserIDTitle = "User"; 
				} 
				return reportUserIDTitle; 
			} 

			set 
			{ 
				reportUserIDTitle = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// Report Page Title for 'ReportID' Property. [Default : Report Id] 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportIDTitle 
		{ 
			get 
			{ 
				if (null == reportIDTitle) 
				{ 
					reportIDTitle = "Report Id"; 
				} 
				return reportIDTitle; 
			} 

			set 
			{ 
				reportIDTitle = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// Report Page Title for 'ReportRunDate' Property. [Default : Run Date] 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportRunDateTitle 
		{ 
			get 
			{ 
				if (null == reportRunDateTitle) 
				{ 
					reportRunDateTitle = "Run Date"; 
				} 
				return reportRunDateTitle; 
			} 

			set 
			{ 
				reportRunDateTitle = value; 
			} 
		} 

		/// <summary> 
		/// set or get 
		/// Report Page Title for 'ReportPageNo' Property. [Default : Page No] 
		/// </summary> 
		[Bindable(true), 
		Category("Appearance"), 
		DefaultValue(""), 
		Browsable(true)] 
		public string ReportPageNoTitle 
		{ 
			get 
			{ 
				if (null == reportPageNoTitle) 
				{ 
					reportPageNoTitle = "Page No"; 
				} 
				return reportPageNoTitle; 
			} 

			set 
			{ 
				reportPageNoTitle = value; 
			} 
		} 
		# endregion Public Properties 

		# region Override OnLoad Event of Control Class 
		/// <summary> 
		/// Override OnLoad Event of Control Class 
		/// </summary> 
		/// <param name="e">Input Event Args e</param> 
		override protected void OnLoad(System.EventArgs e) 
		{
			try 
			{
				dotNetFop = new DotNet.UI.Controls.XslFO();
				ctx = HttpContext.Current; 

				if (null == this.ReportTableInfo) 
				{ 
					DataTable dt = new DataTable(); 
					this.ReportTableInfo = dt; 
				} 

				if ( (this.ReportPageFormat.ToUpper().Equals("P")) || (null == this.ReportPageFormat) ) 
				{ 
					this.ReportPageHeight = "29.7cm"; 
					this.ReportPageWidth = "21cm"; 
				} 
				else if (this.ReportPageFormat.ToUpper().Equals("L")) 
				{ 
					this.ReportPageHeight = "21cm"; 
					this.ReportPageWidth = "29.7cm"; 
				} 
				else 
				{ 
					this.ReportPageHeight = "29.7cm"; 
					this.ReportPageWidth = "21cm"; 
				} 

				stringFoBytes = dotNetFop.GenerateFOBytes(this.ReportDataSource, this.ReportTableInfo, this.ReportTextSize, this.ReportUserID, this.ReportID, this.ReportRunDate, this.ReportLogoURL, this.ReportTitle, this.ReportFoFilePath, this.ReportTitleSize, this.ReportLogoWidth, this.ReportLogoHeight, this.ReportColumnTextSize, this.ReportPageWidth, this.ReportPageHeight, this.ReportIDTitle, this.ReportUserIDTitle, this.ReportPageNoTitle, this.ReportRunDateTitle); 

				if (stringFoBytes.Length > 0) 
				{
					this.DeleteFoFile(this.ReportFoFilePath); 

					using (FileStream fs = File.Create(this.ReportFoFilePath, 1024)) 
					{ 
						fs.Write(stringFoBytes, 0, stringFoBytes.Length); 
					}

					foAsBytes = dotNetFop.IdFopRenderer(this.ReportFoFilePath); 

					if (foAsBytes.Length > 0) 
					{ 
						ctx.Response.ContentType = "application/pdf"; 
						ctx.Response.AddHeader("Content-disposition", "filename=ID.pdf"); 
						ctx.Response.OutputStream.Write(foAsBytes, 0, foAsBytes.Length); 
						ctx.Response.OutputStream.Flush(); 
						ctx.Response.OutputStream.Close();
					} 
					else 
					{ 
						ctx.Response.Write("Problem in Generating PDF Report. Please try again later."); 
					} 
					
					this.DeleteFoFile(this.ReportFoFilePath); 
				}
			} 
			catch (Exception ex) 
			{ 
				ctx.Response.Write("Error in Generating PDF<br>"); 
				ctx.Response.Write(ex.Message); 
				ctx.Response.Write(ex.StackTrace); 
				ctx.Response.Write(ex.InnerException); 
			} 

			//			ctx.Response.Redirect("IdFopError.aspx"); 
		} 
		# endregion Override OnLoad Event of Control Class 

		# region Delete FO File Method 
		private void DeleteFoFile(string strFoPath) 
		{ 
			if (File.Exists(strFoPath)) 
			{ 
				File.Delete(strFoPath); 
			} 
		} 
		# endregion Delete FO File Method 
	} 
	# endregion PDF Server Control
}
