# region .NET NameSpaces 
using System; 
using System.Data; 
using System.IO; 
using System.Web; 
using System.Collections; 
using System.Web.SessionState; 
using System.Text;
# endregion .NET NameSpaces 

# region FOP.NET NameSpaces 
using javax.xml.parsers; 
using org.xml.sax; 
using org.apache.fop.apps; 
using org.apache.fop.layout; 
using org.apache.fop.messaging; 
using org.apache.fop.render; 
using org.apache.fop.render.pdf; 
using org.apache.avalon.framework.logger; 
# endregion FOP.NET NameSpaces 

namespace DotNet.UI.Controls
{ 
	# region XSL-FO Class 
	/// <summary> 
	/// NFOP XSL-FO to PDF Formatter / Converter Class
	/// </summary> 
	public class XslFO
	{ 
		# region Custom Declarations
		sbyte[] sBytes; 
		byte[] getBytes; 

		java.io.ByteArrayOutputStream bos; 
		org.xml.sax.InputSource inputFoFile; 
		# endregion Custom Declarations

		# region Generate FO File and re turn it as a Byte Array
		internal byte[] IdFopRenderer(string strFOPath) 
		{ 
			inputFoFile = new org.xml.sax.InputSource(strFOPath); 
			bos = new java.io.ByteArrayOutputStream(); 
			org.apache.fop.apps.Driver dr = new org.apache.fop.apps.Driver(inputFoFile, bos); 
			dr.setRenderer(org.apache.fop.apps.Driver.RENDER_PDF); 
			dr.run(); 

			sBytes = bos.toByteArray(); 
			getBytes = new byte[sBytes.Length]; 

			for (int i=0; i < sBytes.Length - 1; i++) 
			{ 
				getBytes[i] = (byte) sBytes[i]; 
			} 

			return getBytes; 
		} 
		# endregion Generate FO File and return it as a Byte Array 

		# region Generate FO as string From the Input Params and return it as a Byte Array 
		internal byte[] GenerateFOBytes(DataTable dt, DataTable dtInfo, string strTextSize, string strUserID, string strReportID, string strRunDate, string strImgUrl, string strTitle, string strFOPath, string strTitleSize, string strImgWidth, string strImgHeight, string strColumnTextSize, string strPageWidth, string strPageHeight, string strReportIdTitle, string strUserTitle, string strPageNoTitle, string strRunDateTitle) 
		{
			byte[] setBytes; 
			string strRows = "";
			StringBuilder strFo = new StringBuilder();

			# region Construction of FO File String 

			# region FOP Default Settings 
			strFo.Append("<?xml version='1.0' encoding='UTF-8'?>\n");
			strFo.Append("<fo:root xmlns:fo='http://www.w3.org/1999/XSL/Format'>\n\n"); 
			strFo.Append("\t<fo:layout-master-set>\n"); 
			strFo.Append("\t\t<fo:simple-page-master \n"); 
			strFo.Append("\t\t\tmaster-name='first' \n"); 
			strFo.Append("\t\t\tpage-width='"); 
			strFo.Append(strPageWidth); 
			strFo.Append("' \n"); 
			strFo.Append("\t\t\tpage-height='"); 
			strFo.Append(strPageHeight); 
			strFo.Append("' \n"); 
			strFo.Append("\t\t\tmargin-left='1cm' \n"); 
			strFo.Append("\t\t\tmargin-right='1cm' \n"); 

			if (strPageWidth.ToString().Equals("21cm") && strPageHeight.ToString().Equals("29.7cm")) 
			{ 
				strFo.Append("\t\t\tmargin-top='1cm' \n"); 
			} 
			else if (strPageWidth.ToString().Equals("29.7cm") && strPageHeight.ToString().Equals("21cm")) 
			{ 
				strFo.Append("\t\t\tmargin-top='1cm' \n"); 
			} 

			strFo.Append("\t\t\tmargin-bottom='0.3cm' \n"); 
			strFo.Append("\t\t>\n"); 
			strFo.Append("\t\t\t<fo:region-before \n"); 

			if (strPageWidth.ToString().Equals("21cm") && strPageHeight.ToString().Equals("29.7cm")) 
			{ 
				strFo.Append("\t\t\t\textent='3cm' />\n"); 
			} 
			else if (strPageWidth.ToString().Equals("29.7cm") && strPageHeight.ToString().Equals("21cm")) 
			{ 
				strFo.Append("\t\t\t\textent='3.7cm' />\n"); 
			} 

			strFo.Append("\t\t\t<fo:region-after \n"); 
			strFo.Append("\t\t\t\textent='0.5cm' />\n"); 
			strFo.Append("\t\t\t<fo:region-body \n"); 

			if (strPageWidth.ToString().Equals("21cm") && strPageHeight.ToString().Equals("29.7cm")) 
			{ 
				strFo.Append("\t\t\t\tmargin-top='1.5cm' \n"); 
			} 
			else if (strPageWidth.ToString().Equals("29.7cm") && strPageHeight.ToString().Equals("21cm")) 
			{ 
				strFo.Append("\t\t\t\tmargin-top='3.8cm' \n"); 
			} 

			strFo.Append("\t\t\t\tmargin-bottom='0.3cm' />\n"); 
			strFo.Append("\t\t</fo:simple-page-master>\n"); 
			strFo.Append("\t</fo:layout-master-set>\n\n"); 
			# endregion FOP Default Settings 

			# region FOP Region Before Settings 
			strFo.Append("\t<fo:page-sequence master-reference='first'>\n"); 
			strFo.Append("\t\t<fo:static-content flow-name='xsl-region-before'>\n"); 
			strFo.Append("\t\t\t<fo:block>\n"); 
			strFo.Append("\t\t\t\t<fo:external-graphic \n"); 
			strFo.Append("\t\t\t\t\twidth='" + strImgWidth + "' \n"); 
			strFo.Append("\t\t\t\t\theight='" + strImgHeight + "' \n"); 
			strFo.Append("\t\t\t\t\tsrc='" + strImgUrl + "'/>\n"); 
			strFo.Append("\t\t\t</fo:block>\n"); 
			strFo.Append("\t\t\t<fo:block line-height='20pt' font-size='" + strTitleSize + "' font-weight='bold' text-align='center' >\n"); 
			strFo.Append("\t\t\t\t" + strTitle + "\n"); 
			strFo.Append("\t\t\t</fo:block>\n"); 

			# region FOP Block Container Title Settings 
			if (strPageWidth.ToString().Equals("21cm") && strPageHeight.ToString().Equals("29.7cm")) 
			{ 
				//				// Portrait Block Container Begin 
				//				strFo += "\t\t\t<fo:block-container height='1cm' width='12cm' top='1.6cm' left='0cm' position='absolute'>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t"; 
				//				strFo += strReportIdTitle; 
				//				strFo += " \n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t"; 
				//				strFo += strUserTitle; 
				//				strFo += " \n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t</fo:block-container>\n"; 
				//				strFo += "\t\t\t<fo:block-container height='1cm' width='12cm' top='1.6cm' left='15.8cm' position='absolute'>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t"; 
				//				strFo += strPageNoTitle; 
				//				strFo += " \n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t"; 
				//				strFo += strRunDateTitle; 
				//				strFo += " \n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t</fo:block-container>\n\n"; 
				//				// Portrait Block Container End 
				//			} 
				//			else if (strPageWidth.ToString().Equals("29.7cm") && strPageHeight.ToString().Equals("21cm")) 
				//			{ 
				//				// Landscape Block Container Begin 
				//				strFo += "\t\t\t<fo:block-container height='1cm' width='12cm' top='2.2cm' left='0cm' position='absolute'>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t"; 
				//				strFo += strReportIdTitle; 
				//				strFo += " \n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t"; 
				//				strFo += strUserTitle; 
				//				strFo += " \n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t</fo:block-container>\n"; 
				//				strFo += "\t\t\t<fo:block-container height='1cm' width='12cm' top='2.2cm' left='24.7cm' position='absolute'>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t"; 
				//				strFo += strPageNoTitle; 
				//				strFo += " \n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t"; 
				//				strFo += strRunDateTitle; 
				//				strFo += " \n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t</fo:block-container>\n\n"; 
				//				// Landscape Block Container End 
			} 
			# endregion FOP Block Container Title Settings 

			# region FOP Block Container Title Value Settings 
			if (strPageWidth.ToString().Equals("21cm") && strPageHeight.ToString().Equals("29.7cm")) 
			{ 
				// Portrait Block Container Begin 
				//				strFo += "\t\t\t<fo:block-container height='1cm' width='12cm' top='1.6cm' left='1.6cm' position='absolute'>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t : " + strReportID + "\n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t : " + strUserID + "\n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t</fo:block-container>\n"; 
				//				strFo += "\t\t\t<fo:block-container height='1cm' width='12cm' top='1.6cm' left='17.3cm' position='absolute'>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t : <fo:page-number /> <fo:page-nuber-citation ref-id='lastpage' />\n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t : " + strRunDate + "\n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t</fo:block-container>\n\n"; 
				//				// Portrait Block Container End 
				//			} 
				//			else if (strPageWidth.ToString().Equals("29.7cm") && strPageHeight.ToString().Equals("21cm")) 
				//			{ 
				//				// Landscape Block Container Begin 
				//				strFo += "\t\t\t<fo:block-container height='1cm' width='12cm' top='2.2cm' left='1.6cm' position='absolute'>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t : " + strReportID + "\n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t : " + strUserID + "\n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t</fo:block-container>\n"; 
				//				strFo += "\t\t\t<fo:block-container height='1cm' width='12cm' top='2.2cm' left='26.3cm' position='absolute'>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t : <fo:page-number /> <fo:page-nuber-citation ref-id='lastpage' />\n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t\t<fo:block line-height='10pt' text-align='start' font-size='8pt' font-weight='bold' >\n"; 
				//				strFo += "\t\t\t\t\t : " + strRunDate + "\n"; 
				//				strFo += "\t\t\t\t</fo:block>\n"; 
				//				strFo += "\t\t\t</fo:block-container>\n\n"; 
				//				// Landscape Block Container End 
			} 
			# endregion FOP Block Container Title Value Settings 

			# endregion FOP Region Before Settings 

			# region FOP Region Body Settings 
			if (null == dt) 
			{ 
				# region If DataTable instance dt is NULL 
				strFo.Append("\t\t</fo:static-content>\n\n"); 

				// FO Page Body Starts 
				strFo.Append("\t\t<fo:flow flow-name='xsl-region-body'>\n"); 

				strFo.Append("\t\t\t<fo:block font-size='16' text-align='center' font-weight='bold' color='red' >"); 
				strFo.Append("'ReportDataSource' Property for the FOP:IdPdf Server Control Not Set"); 
				strFo.Append("</fo:block>\n"); 

				strFo.Append("\t\t\t<fo:block font-size='10' text-align='left' font-weight='bold' >"); 
				strFo.Append("1. Bind a DataTable with Data for 'ReportDataSource' Property"); 
				strFo.Append("</fo:block>\n"); 

				strFo.Append("\t\t\t<fo:block font-size='10' text-align='left' font-weight='bold' >"); 
				strFo.Append("2. Add all the Display Column Names for 'ColumnName' Property in a new 'DataTable' and Display Column's Width as 0'th Row in the same 'DataTable' and Bind the DataTable for 'ReportTableInfo' Property"); 
				strFo.Append("</fo:block>\n"); 

				strFo.Append("\t\t\t<fo:block font-size='10' text-align='left' font-weight='bold' >"); 
				strFo.Append("3. Column Count for the DataTable bound for 'ReportDataSource' and 'ReportTableInfo' should be same"); 
				strFo.Append("</fo:block>\n"); 
				# endregion If DataTable instance dt is NULL 
			} 
			else 
			{ 
				try 
				{ 
					# region If DataTable instance dt is NOT NULL 
					strFo.Append("\t\t\t<fo:block line-height='1pt' text-align='center' >\n"); 
					strFo.Append("\t\t\t\t<fo:leader leader-pattern='rule' rule-thickness='1pt' leader-length='100%' />\n"); 
					strFo.Append("\t\t\t</fo:block>\n"); 

					# region Initialising fo:table-column 
					// Constructing Column Names from DataTable DataInfo 
					strFo.Append("\t\t\t<fo:table border-style='solid' border-width='0.0pt' table-layout='fixed' space-before.optimum='5pt'>\n"); 
					// If dtInfo DataTable has Columns Set, Initialise fo:table-column 
					if (dtInfo.Columns.Count > 0) 
					{ 
						for (int i=0; i < dtInfo.Columns.Count; i++) 
						{ 
							strFo.Append("\t\t\t\t<fo:table-column column-width='"); 

							if (dtInfo.Rows.Count > 0) 
							{ 
								strFo.Append(dtInfo.Rows[0][i].ToString()); 
							} 
							else 
							{ 
								strFo.Append("2cm"); 
							} 

							strFo.Append("'/>\n"); 
						} 
					} 
						// Else, Initialise fo:table-column from DataTable dt 
					else if (dt.Columns.Count > 0) 
					{ 
						for (int i=0; i < dt.Columns.Count; i++) 
						{ 
							strFo.Append("\t\t\t\t<fo:table-column column-width='2cm'/>\n"); 
						} 
					} 
					# endregion Initialising fo:table-column 

					strFo.Append("\n\t\t\t\t<fo:table-body>\n"); 
					strFo.Append("\t\t\t\t\t<fo:table-row >\n"); 

					# region Set Column Names form DataTable dtInfo if available, Else set from dt 
					// Set Column Names from DataTable dtInfo 
					if (dtInfo.Columns.Count > 0) 
					{ 
						for (int i=0; i < dtInfo.Columns.Count; i++) 
						{ 
							strFo.Append("\t\t\t\t\t\t<fo:table-cell border-style='solid' border-top='0.0pt' border-bottom='0.0pt' border-left='0.0pt' border-right='0.0pt' >\n"); 
							strFo.Append("\t\t\t\t\t\t\t<fo:block text-align='left' font-weight='bold' font-size='" + strColumnTextSize + "' space-before.optimum='1pt'>\n"); 
							strFo.Append("\t\t\t\t\t\t\t\t" + dtInfo.Columns[i].ColumnName + "\n"); 
							strFo.Append("\t\t\t\t\t\t\t</fo:block>\n"); 
							strFo.Append("\t\t\t\t\t\t</fo:table-cell>\n"); 
						} 
					} 
						// Else, Set Column Names from DataTable dt 
					else if (dt.Columns.Count > 0) 
					{ 
						for (int i=0; i < dt.Columns.Count; i++) 
						{ 
							strFo.Append("\t\t\t\t\t\t<fo:table-cell border-style='solid' border-top='0.0pt' border-bottom='0.0pt' border-left='0.0pt' border-right='0.0pt' >\n"); 
							strFo.Append("\t\t\t\t\t\t\t<fo:block text-align='left' font-weight='bold' font-size='" + strColumnTextSize + "' space-before.optimum='1pt'>\n"); 
							strFo.Append("\t\t\t\t\t\t\t\t" + dt.Columns[i].ColumnName + "\n"); 
							strFo.Append("\t\t\t\t\t\t\t</fo:block>\n"); 
							strFo.Append("\t\t\t\t\t\t</fo:table-cell>\n"); 
						} 
					} 
					# endregion Set Column Names form DataTable dtInfo if available, Else set from dt 

					strFo.Append("\t\t\t\t\t</fo:table-row>\n"); 
					strFo.Append("\t\t\t\t</fo:table-body>\n"); 
					strFo.Append("\t\t\t</fo:table>\n"); 

					strFo.Append("\t\t\t<fo:block line-height='1pt' text-align='center' >\n"); 
					strFo.Append("\t\t\t\t<fo:leader leader-pattern='rule' rule-thickness='1pt' leader-length='100%' />\n"); 
					strFo.Append("\t\t\t</fo:block>\n"); 
					# endregion If DataTable instance dt is NOT NULL 
				} 
				catch (Exception ex) 
				{ 
					# region DataTable dt Exception Block 
					strFo.Append("\t\t\t<fo:table border-style='solid' border-width='1.0pt' table-layout='fixed' space-before.optimum='1pt'>\n"); 
					strFo.Append("\t\t\t\t<fo:table-column column-width='17.8cm'/>\n"); 
					strFo.Append("\n\t\t\t\t<fo:table-body>\n"); 
					strFo.Append("\t\t\t\t\t<fo:table-row >\n"); 
					strFo.Append("\t\t\t\t\t\t<fo:table-cell border-style='solid' border-top='1.0pt' border-bottom='1.0pt' border-left='1.0pt' border-right='1.0pt' >\n"); 
					strFo.Append("\t\t\t\t\t\t\t<fo:block text-align='center' color='red' font-weight='bold' font-size='" + strColumnTextSize + "' space-before.optimum='1pt'>\n"); 
					strFo.Append("\t\t\t\t\t\t\t\tError in Generating PDF Report : "+ ex.Message +"\n"); 
					strFo.Append("\t\t\t\t\t\t\t</fo:block>\n"); 
					strFo.Append("\t\t\t\t\t\t</fo:table-cell>\n"); 
					strFo.Append("\t\t\t\t\t</fo:table-row>\n"); 
					strFo.Append("\t\t\t\t</fo:table-body>\n"); 
					strFo.Append("\t\t\t</fo:table>\n"); 
					# endregion DataTable dt Exception Block 
				} 

				strFo.Append("\t\t</fo:static-content>\n\n"); 

				# region FO Page Body 
				// FO Page Body Starts 
				strFo.Append("\t\t<fo:flow flow-name='xsl-region-body'>\n"); 

				try 
				{ 
					// Constructing Data from DataTable DataSource 
					strFo.Append("\t\t\t<fo:table border-style='solid' border-width='0.0pt' table-layout='fixed' space-before.optimum='1pt'>\n"); 
					
					# region Constructing Data from DataTable DataSource 

					# region Set Column Width to Construct fo:table for Display Data from DataTable dt 
					if (dtInfo.Columns.Count > 0) 
					{ 
						# region Set Column Width from DataTable dtInfo Row[0], if available 
						for (int i=0; i < dtInfo.Columns.Count; i++) 
						{ 
							strFo.Append("\t\t\t\t<fo:table-column column-width='"); 

							if (dtInfo.Rows.Count > 0) 
							{ 
								strFo.Append(dtInfo.Rows[0][i].ToString()); 
							} 
							else 
							{ 
								strFo.Append("2cm"); 
							} 

							strFo.Append("'/>\n"); 
						} 
						# endregion Set Column Width from DataTable dtInfo Row[0], if available 
					} 
					else if (dt.Columns.Count > 0) 
					{ 
						# region Else, Set Column Width as 2cm 
						for (int i=0; i < dt.Columns.Count; i++) 
						{ 
							strFo.Append("\t\t\t\t<fo:table-column column-width='2cm'/>\n"); 
						} 
						# endregion Else, Set Column Width as 2cm 
					} 
					# endregion Set Column Width to Construct fo:table for Display Data from DataTable dt 

					strFo.Append("\n\t\t\t\t<fo:table-body>\n"); 

					// Adding FO DataTable Row Data in a string strRows 
					if (dt.Rows.Count > 0) 
					{ 
						# region Add Data if available in DataTable dt to a fo:table 
						for (int j=0; j < dt.Rows.Count; j++) 
						{ 
							strFo.Append("\t\t\t\t\t<!-- Row "+ j +" Begin -->\n"); 
							strFo.Append("\t\t\t\t\t\t<fo:table-row>\n"); 

							if (dt.Columns.Count > 0) 
							{ 
								# region If DataTable dt has Column Count > 0, Add Data in fo:table 
								for (int i=0; i < dt.Columns.Count; i++) 
								{ 
									strFo.Append("\t\t\t\t\t\t\t<fo:table-cell border-style='solid' border-width='0.0pt'>\n"); 
									strFo.Append("\t\t\t\t\t\t\t\t<fo:block font-size='" + strTextSize + "' text-align='left' >"); 
									strFo.Append(dt.Rows[j][i].ToString()); 
									strFo.Append("</fo:block>\n"); 
									strFo.Append("\t\t\t\t\t\t\t</fo:table-cell>\n"); 
								} 
								# endregion If DataTable dt has Column Count > 0, Add Data in fo:table 
							} 
							else 
							{ 
								# region Else, Display both DataTable instances dt and dtInfo does not have any columns and rows 
								strFo.Append("\t\t\t\t\t\t\t<fo:table-cell border-style='solid' border-width='0.0pt'>\n"); 
								strFo.Append("\t\t\t\t\t\t\t\t<fo:block font-size='" + strTextSize + "' text-align='left' >"); 
								strFo.Append("Column Names are Not Defined in DataTable 'ReportDataSource' / DataTable 'ReportTableInfo'"); 
								strFo.Append("</fo:block>\n"); 
								strFo.Append("\t\t\t\t\t\t\t</fo:table-cell>\n"); 
								# endregion Else, Display both DataTable instances dt and dtInfo does not have any columns and rows 
							} 

							strFo.Append("\t\t\t\t\t\t</fo:table-row>\n"); 
							strFo.Append("\t\t\t\t\t<!-- Row "+ j +" End -->\n"); 
						} 

						strFo.Append("\t\t\t\t</fo:table-body>\n"); 
						strFo.Append("\t\t\t</fo:table>\n\n"); 
						# endregion Add Data if available in DataTable dt to a fo:table 
					} 
					else 
					{ 
						# region Else, Display as 'No Rows Found' 
						strFo.Append("\t\t\t\t\t\t<fo:table-row>\n"); 
						strFo.Append("\t\t\t\t\t\t\t<fo:table-cell border-style='solid' border-width='0.0pt' display-align='center'>\n"); 
						strFo.Append("\t\t\t\t\t\t\t</fo:table-cell>\n"); 
						strFo.Append("\t\t\t\t\t\t</fo:table-row>\n"); 
						strFo.Append("\t\t\t\t</fo:table-body>\n"); 
						strFo.Append("\t\t\t</fo:table>\n\n"); 

						strFo.Append("\t\t\t\t\t<!-- Row NO DATA FOUND Begin -->\n"); 
						strFo.Append("\t\t\t\t\t\t\t\t<fo:block font-size='14' text-align='center' font-weight='bold' >"); 
						strFo.Append("No Rows Found."); 
						strFo.Append("</fo:block>\n"); 
						strFo.Append("\t\t\t\t\t<!-- Row NO DATA FOUND End -->\n"); 
						# endregion Else, Display as 'No Rows Found' 
					} 
					# endregion Constructing Data from DataTable DataSource 
				} 
				catch (Exception ex) 
				{ 
					# region FO Page Body Exception Block 
					strFo.Append("\t\t\t<fo:table border-style='solid' border-width='0.0pt' table-layout='fixed' space-before.optimum='1pt'>\n"); 
					strFo.Append("\t\t\t\t<fo:table-column column-width='17.8cm'/>\n"); 
					strFo.Append("\n\t\t\t\t<fo:table-body>\n"); 
					strFo.Append("\t\t\t\t\t<fo:table-row >\n"); 
					strFo.Append("\t\t\t\t\t\t<fo:table-cell border-style='solid' border-top='1.0pt' border-bottom='1.0pt' border-left='1.0pt' border-right='1.0pt' >\n"); 
					strFo.Append("\t\t\t\t\t\t\t<fo:block text-align='center' color='red' font-weight='bold' font-size='" + strColumnTextSize + "' space-before.optimum='1pt'>\n"); 
					strFo.Append("\t\t\t\t\t\t\t\tError in Generating PDF Report : "+ ex.Message +"\n"); 
					strFo.Append("\t\t\t\t\t\t\t</fo:block>\n"); 
					strFo.Append("\t\t\t\t\t\t</fo:table-cell>\n"); 
					strFo.Append("\t\t\t\t\t</fo:table-row>\n"); 
					strFo.Append("\t\t\t\t</fo:table-body>\n"); 
					strFo.Append("\t\t\t</fo:table>\n"); 
					# endregion FO Page Body Exception Block 
				} 
				# endregion FO Page Body 
			} 

			// Adding string strRows which has Report Row Data with string strFo 
			strFo.Append(strRows); 

			// Adding A Line at the Last Page to represent the End of Report 
			strFo.Append("\t\t\t<fo:block line-height='1pt' text-align='center' >\n"); 
			strFo.Append("\t\t\t\t<fo:leader leader-pattern='rule' rule-thickness='1pt' leader-length='100%' />\n"); 
			strFo.Append("\t\t\t</fo:block>\n"); 

			strFo.Append("\t\t\t<fo:block id='lastpage' />\n"); 
			strFo.Append("\t\t</fo:flow>\n"); 
			strFo.Append("\t</fo:page-sequence>\n"); 
			strFo.Append("</fo:root>\n"); 
			# endregion FOP Region Body Settings 

			# endregion Construction of FO File String 

			setBytes = new byte[strFo.Length]; 
			setBytes = System.Text.Encoding.ASCII.GetBytes(strFo.ToString()); 

			return setBytes; 
		} 
		# endregion Generate FO as string From the Input Params and return it as a Byte Array 
	} 
	# endregion XSL-FO Class 
}
