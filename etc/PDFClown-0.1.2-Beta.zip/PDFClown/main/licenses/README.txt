License
PDF Clown Project [../README.html] > 


Project version: 0.1.2 - README revision: 0 (2013-02-04)

---------------
Introduction
---------------
This section hosts the licenses applied to PDF Clown.


---------------
Resources
---------------
 * GNU LGPL [gnu.org/lgpl.html]: GNU Lesser General Public License version 3
 * GNU FDL [gnu.org/fdl.html]: GNU Free Documentation License version 1.2
 * Navigation:
  * Current directory [.]: browse current section contents
  * Parent section [../README.html]: move to parent section
  * Previous section [../../dotNET/README.html]: move to previous section
  * Next section [../doc/README.html]: move to next section
  * INDEX [../INDEX.html]: move to the distribution map
