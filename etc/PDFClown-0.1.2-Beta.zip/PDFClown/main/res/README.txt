Additional resources
PDF Clown Project [../README.html] > 


Project version: 0.1.2 - README revision: 0 (2013-02-04)

---------------
Introduction
---------------
This section contains material related to the PDF Clown distribution, such as stylesheets and documentation in source format.


---------------
Resources
---------------
 * Documentation sources [doc/]: PDF Clown's documentation in source format.
 * Package resources [pkg/]: Resources to include inside the compiled library.
 * Sample files [samples/input/]: Sample resources (fonts, images, PDFs...) used to feed PDF Clown's sample applications.
 * Scripts [script/]: Utility shell scripts [http://en.wikipedia.org/wiki/Shell_script].
 * Stylesheets [xsl/]: XSLT stylesheets [http://en.wikipedia.org/wiki/Xslt] for data trasformation.
 * Navigation:
  * Current directory [.]: browse current section contents
  * Parent section [../README.html]: move to parent section
  * Previous section [../doc/README.html]: move to previous section
  * Next section [../CREDITS.html]: move to next section
  * INDEX [../INDEX.html]: move to the distribution map
