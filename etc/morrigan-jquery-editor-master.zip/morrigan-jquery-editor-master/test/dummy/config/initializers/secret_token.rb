# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Dummy::Application.config.secret_token = '51a8253dcb45cb4e6ba4527af529058e8c5688f6e0c77d7be6a1acdd5154171410bc55a3f2d45855929737195e9874b6f0524dc3204953f239d5c2f4fcca01c7'
