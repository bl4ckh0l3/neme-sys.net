﻿namespace HiQPdf_Demo
{
    partial class ConvertHtmlToPdf
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConvertHtmlToPdf));
            this.topPanel = new System.Windows.Forms.Panel();
            this.panelSeparator = new System.Windows.Forms.Panel();
            this.flowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.panelMargin = new System.Windows.Forms.Panel();
            this.bottomPanel = new System.Windows.Forms.Panel();
            this.leftPanel = new System.Windows.Forms.Panel();
            this.rightPanel = new System.Windows.Forms.Panel();
            this.buttonConvertToPdf = new System.Windows.Forms.Button();
            this.comboBoxPageOrientation = new System.Windows.Forms.ComboBox();
            this.comboBoxPageSize = new System.Windows.Forms.ComboBox();
            this.textBoxBrowserWidth = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxUrl = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblUrlField = new System.Windows.Forms.Label();
            this.panelSelectHtmlInput = new System.Windows.Forms.Panel();
            this.radioButtonConvertHtmlCode = new System.Windows.Forms.RadioButton();
            this.radioButtonConvertUrl = new System.Windows.Forms.RadioButton();
            this.panelEnterUrl = new System.Windows.Forms.Panel();
            this.panelEnterHtmlCode = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxBaseUrl = new System.Windows.Forms.TextBox();
            this.textBoxHtmlCode = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panelSettings = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxWaitTime = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBoxBrowserHeight = new System.Windows.Forms.TextBox();
            this.textBoxLoadHtmlTimeout = new System.Windows.Forms.TextBox();
            this.panelConvertButton = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.topPanel.SuspendLayout();
            this.panelSelectHtmlInput.SuspendLayout();
            this.panelEnterUrl.SuspendLayout();
            this.panelEnterHtmlCode.SuspendLayout();
            this.panelSettings.SuspendLayout();
            this.panelConvertButton.SuspendLayout();
            this.SuspendLayout();
            // 
            // topPanel
            // 
            this.topPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.topPanel.Controls.Add(this.label16);
            this.topPanel.Controls.Add(this.panel1);
            this.topPanel.Controls.Add(this.label9);
            this.topPanel.Controls.Add(this.panelSeparator);
            this.topPanel.Controls.Add(this.flowLayoutPanel);
            this.topPanel.Controls.Add(this.panelMargin);
            this.topPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.topPanel.Location = new System.Drawing.Point(0, 0);
            this.topPanel.Name = "topPanel";
            this.topPanel.Size = new System.Drawing.Size(566, 96);
            this.topPanel.TabIndex = 0;
            // 
            // panelSeparator
            // 
            this.panelSeparator.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelSeparator.Location = new System.Drawing.Point(0, 86);
            this.panelSeparator.Name = "panelSeparator";
            this.panelSeparator.Size = new System.Drawing.Size(566, 10);
            this.panelSeparator.TabIndex = 3;
            // 
            // flowLayoutPanel
            // 
            this.flowLayoutPanel.AutoSize = true;
            this.flowLayoutPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.flowLayoutPanel.Location = new System.Drawing.Point(0, 5);
            this.flowLayoutPanel.Name = "flowLayoutPanel";
            this.flowLayoutPanel.Size = new System.Drawing.Size(566, 0);
            this.flowLayoutPanel.TabIndex = 2;
            // 
            // panelMargin
            // 
            this.panelMargin.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMargin.Location = new System.Drawing.Point(0, 0);
            this.panelMargin.Name = "panelMargin";
            this.panelMargin.Size = new System.Drawing.Size(566, 5);
            this.panelMargin.TabIndex = 1;
            // 
            // bottomPanel
            // 
            this.bottomPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bottomPanel.Location = new System.Drawing.Point(0, 665);
            this.bottomPanel.Name = "bottomPanel";
            this.bottomPanel.Size = new System.Drawing.Size(566, 6);
            this.bottomPanel.TabIndex = 1;
            // 
            // leftPanel
            // 
            this.leftPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.leftPanel.Location = new System.Drawing.Point(0, 96);
            this.leftPanel.Name = "leftPanel";
            this.leftPanel.Size = new System.Drawing.Size(6, 569);
            this.leftPanel.TabIndex = 2;
            // 
            // rightPanel
            // 
            this.rightPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.rightPanel.Location = new System.Drawing.Point(560, 96);
            this.rightPanel.Name = "rightPanel";
            this.rightPanel.Size = new System.Drawing.Size(6, 569);
            this.rightPanel.TabIndex = 3;
            // 
            // buttonConvertToPdf
            // 
            this.buttonConvertToPdf.Location = new System.Drawing.Point(9, 6);
            this.buttonConvertToPdf.Name = "buttonConvertToPdf";
            this.buttonConvertToPdf.Size = new System.Drawing.Size(135, 27);
            this.buttonConvertToPdf.TabIndex = 66;
            this.buttonConvertToPdf.Text = "Convert to PDF";
            this.buttonConvertToPdf.UseVisualStyleBackColor = true;
            this.buttonConvertToPdf.Click += new System.EventHandler(this.buttonConvertToPdf_Click);
            // 
            // comboBoxPageOrientation
            // 
            this.comboBoxPageOrientation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPageOrientation.FormattingEnabled = true;
            this.comboBoxPageOrientation.Items.AddRange(new object[] {
            "Portrait",
            "Landscape"});
            this.comboBoxPageOrientation.Location = new System.Drawing.Point(366, 37);
            this.comboBoxPageOrientation.Name = "comboBoxPageOrientation";
            this.comboBoxPageOrientation.Size = new System.Drawing.Size(116, 23);
            this.comboBoxPageOrientation.TabIndex = 51;
            // 
            // comboBoxPageSize
            // 
            this.comboBoxPageSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPageSize.FormattingEnabled = true;
            this.comboBoxPageSize.Items.AddRange(new object[] {
            "A0",
            "A1",
            "A2",
            "A3",
            "A4",
            "A5",
            "A6",
            "A7",
            "A8",
            "A9",
            "A10",
            "B0",
            "B1",
            "B2",
            "B3",
            "B4",
            "B5",
            "ArchA",
            "ArchB",
            "ArchC",
            "ArchD",
            "ArchE",
            "Flsa",
            "HalfLetter",
            "Ledger",
            "Legal",
            "Letter",
            "Letter11x17",
            "Note"});
            this.comboBoxPageSize.Location = new System.Drawing.Point(83, 37);
            this.comboBoxPageSize.Name = "comboBoxPageSize";
            this.comboBoxPageSize.Size = new System.Drawing.Size(110, 23);
            this.comboBoxPageSize.TabIndex = 52;
            // 
            // textBoxBrowserWidth
            // 
            this.textBoxBrowserWidth.Location = new System.Drawing.Point(99, 121);
            this.textBoxBrowserWidth.Name = "textBoxBrowserWidth";
            this.textBoxBrowserWidth.Size = new System.Drawing.Size(43, 21);
            this.textBoxBrowserWidth.TabIndex = 46;
            this.textBoxBrowserWidth.Text = "1200";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(146, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 15);
            this.label3.TabIndex = 43;
            this.label3.Text = "px";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(255, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 15);
            this.label5.TabIndex = 42;
            this.label5.Text = "Page Orientation:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 15);
            this.label4.TabIndex = 45;
            this.label4.Text = "Page Size: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 15);
            this.label2.TabIndex = 44;
            this.label2.Text = "Browser Width:";
            // 
            // textBoxUrl
            // 
            this.textBoxUrl.Location = new System.Drawing.Point(8, 30);
            this.textBoxUrl.Name = "textBoxUrl";
            this.textBoxUrl.Size = new System.Drawing.Size(530, 21);
            this.textBoxUrl.TabIndex = 41;
            this.textBoxUrl.Text = "http://www.hiqpdf.com";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label1.Location = new System.Drawing.Point(6, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 15);
            this.label1.TabIndex = 39;
            this.label1.Text = "PDF Settings";
            // 
            // lblUrlField
            // 
            this.lblUrlField.AutoSize = true;
            this.lblUrlField.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.lblUrlField.Location = new System.Drawing.Point(6, 12);
            this.lblUrlField.Name = "lblUrlField";
            this.lblUrlField.Size = new System.Drawing.Size(119, 15);
            this.lblUrlField.TabIndex = 40;
            this.lblUrlField.Text = "URL or Local File";
            // 
            // panelSelectHtmlInput
            // 
            this.panelSelectHtmlInput.Controls.Add(this.radioButtonConvertHtmlCode);
            this.panelSelectHtmlInput.Controls.Add(this.radioButtonConvertUrl);
            this.panelSelectHtmlInput.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSelectHtmlInput.Location = new System.Drawing.Point(6, 96);
            this.panelSelectHtmlInput.Name = "panelSelectHtmlInput";
            this.panelSelectHtmlInput.Size = new System.Drawing.Size(554, 33);
            this.panelSelectHtmlInput.TabIndex = 67;
            // 
            // radioButtonConvertHtmlCode
            // 
            this.radioButtonConvertHtmlCode.AutoSize = true;
            this.radioButtonConvertHtmlCode.Location = new System.Drawing.Point(151, 6);
            this.radioButtonConvertHtmlCode.Name = "radioButtonConvertHtmlCode";
            this.radioButtonConvertHtmlCode.Size = new System.Drawing.Size(135, 19);
            this.radioButtonConvertHtmlCode.TabIndex = 69;
            this.radioButtonConvertHtmlCode.Text = "Convert HTML Code";
            this.radioButtonConvertHtmlCode.UseVisualStyleBackColor = true;
            this.radioButtonConvertHtmlCode.CheckedChanged += new System.EventHandler(this.radioButtonConvertHtmlCode_CheckedChanged);
            // 
            // radioButtonConvertUrl
            // 
            this.radioButtonConvertUrl.AutoSize = true;
            this.radioButtonConvertUrl.Checked = true;
            this.radioButtonConvertUrl.Location = new System.Drawing.Point(6, 6);
            this.radioButtonConvertUrl.Name = "radioButtonConvertUrl";
            this.radioButtonConvertUrl.Size = new System.Drawing.Size(94, 19);
            this.radioButtonConvertUrl.TabIndex = 68;
            this.radioButtonConvertUrl.TabStop = true;
            this.radioButtonConvertUrl.Text = "Convert URL";
            this.radioButtonConvertUrl.UseVisualStyleBackColor = true;
            this.radioButtonConvertUrl.CheckedChanged += new System.EventHandler(this.radioButtonConvertUrl_CheckedChanged);
            // 
            // panelEnterUrl
            // 
            this.panelEnterUrl.Controls.Add(this.lblUrlField);
            this.panelEnterUrl.Controls.Add(this.textBoxUrl);
            this.panelEnterUrl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelEnterUrl.Location = new System.Drawing.Point(6, 129);
            this.panelEnterUrl.Name = "panelEnterUrl";
            this.panelEnterUrl.Size = new System.Drawing.Size(554, 62);
            this.panelEnterUrl.TabIndex = 68;
            // 
            // panelEnterHtmlCode
            // 
            this.panelEnterHtmlCode.Controls.Add(this.label14);
            this.panelEnterHtmlCode.Controls.Add(this.textBoxBaseUrl);
            this.panelEnterHtmlCode.Controls.Add(this.textBoxHtmlCode);
            this.panelEnterHtmlCode.Controls.Add(this.label12);
            this.panelEnterHtmlCode.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelEnterHtmlCode.Location = new System.Drawing.Point(6, 191);
            this.panelEnterHtmlCode.Name = "panelEnterHtmlCode";
            this.panelEnterHtmlCode.Size = new System.Drawing.Size(554, 207);
            this.panelEnterHtmlCode.TabIndex = 69;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label14.Location = new System.Drawing.Point(6, 156);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(271, 15);
            this.label14.TabIndex = 42;
            this.label14.Text = "Base URL to Resolve External Resources";
            // 
            // textBoxBaseUrl
            // 
            this.textBoxBaseUrl.Location = new System.Drawing.Point(8, 174);
            this.textBoxBaseUrl.Name = "textBoxBaseUrl";
            this.textBoxBaseUrl.Size = new System.Drawing.Size(531, 21);
            this.textBoxBaseUrl.TabIndex = 43;
            // 
            // textBoxHtmlCode
            // 
            this.textBoxHtmlCode.Location = new System.Drawing.Point(9, 25);
            this.textBoxHtmlCode.MaxLength = 1000000;
            this.textBoxHtmlCode.Multiline = true;
            this.textBoxHtmlCode.Name = "textBoxHtmlCode";
            this.textBoxHtmlCode.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxHtmlCode.Size = new System.Drawing.Size(529, 118);
            this.textBoxHtmlCode.TabIndex = 41;
            this.textBoxHtmlCode.Text = "Please enter the HTML code to convert and the base URL to access the external ima" +
    "ges, scripts and css having relative URLs in the HTML code to convert.";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label12.Location = new System.Drawing.Point(6, 6);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 15);
            this.label12.TabIndex = 40;
            this.label12.Text = "HTML Code";
            // 
            // panelSettings
            // 
            this.panelSettings.Controls.Add(this.label10);
            this.panelSettings.Controls.Add(this.label11);
            this.panelSettings.Controls.Add(this.textBoxWaitTime);
            this.panelSettings.Controls.Add(this.label8);
            this.panelSettings.Controls.Add(this.label1);
            this.panelSettings.Controls.Add(this.label21);
            this.panelSettings.Controls.Add(this.label7);
            this.panelSettings.Controls.Add(this.label2);
            this.panelSettings.Controls.Add(this.label4);
            this.panelSettings.Controls.Add(this.label5);
            this.panelSettings.Controls.Add(this.label6);
            this.panelSettings.Controls.Add(this.label20);
            this.panelSettings.Controls.Add(this.label3);
            this.panelSettings.Controls.Add(this.textBoxBrowserHeight);
            this.panelSettings.Controls.Add(this.textBoxLoadHtmlTimeout);
            this.panelSettings.Controls.Add(this.textBoxBrowserWidth);
            this.panelSettings.Controls.Add(this.comboBoxPageSize);
            this.panelSettings.Controls.Add(this.comboBoxPageOrientation);
            this.panelSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSettings.Location = new System.Drawing.Point(6, 398);
            this.panelSettings.Name = "panelSettings";
            this.panelSettings.Size = new System.Drawing.Size(554, 213);
            this.panelSettings.TabIndex = 70;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label10.Location = new System.Drawing.Point(192, 166);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 15);
            this.label10.TabIndex = 70;
            this.label10.Text = "Wait Time:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label11.Location = new System.Drawing.Point(304, 166);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(26, 15);
            this.label11.TabIndex = 71;
            this.label11.Text = "sec";
            // 
            // textBoxWaitTime
            // 
            this.textBoxWaitTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.textBoxWaitTime.Location = new System.Drawing.Point(268, 162);
            this.textBoxWaitTime.Name = "textBoxWaitTime";
            this.textBoxWaitTime.Size = new System.Drawing.Size(30, 21);
            this.textBoxWaitTime.TabIndex = 69;
            this.textBoxWaitTime.Text = "2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label8.Location = new System.Drawing.Point(6, 90);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(115, 15);
            this.label8.TabIndex = 39;
            this.label8.Text = "Browser Settings";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 166);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(55, 15);
            this.label21.TabIndex = 44;
            this.label21.Text = "Timeout:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(192, 124);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 15);
            this.label7.TabIndex = 44;
            this.label7.Text = "Browser Height:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(337, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 15);
            this.label6.TabIndex = 43;
            this.label6.Text = "px";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(105, 166);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(26, 15);
            this.label20.TabIndex = 43;
            this.label20.Text = "sec";
            // 
            // textBoxBrowserHeight
            // 
            this.textBoxBrowserHeight.Location = new System.Drawing.Point(290, 121);
            this.textBoxBrowserHeight.Name = "textBoxBrowserHeight";
            this.textBoxBrowserHeight.Size = new System.Drawing.Size(43, 21);
            this.textBoxBrowserHeight.TabIndex = 46;
            // 
            // textBoxLoadHtmlTimeout
            // 
            this.textBoxLoadHtmlTimeout.Location = new System.Drawing.Point(69, 163);
            this.textBoxLoadHtmlTimeout.Name = "textBoxLoadHtmlTimeout";
            this.textBoxLoadHtmlTimeout.Size = new System.Drawing.Size(31, 21);
            this.textBoxLoadHtmlTimeout.TabIndex = 46;
            this.textBoxLoadHtmlTimeout.Text = "120";
            // 
            // panelConvertButton
            // 
            this.panelConvertButton.Controls.Add(this.buttonConvertToPdf);
            this.panelConvertButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelConvertButton.Location = new System.Drawing.Point(6, 611);
            this.panelConvertButton.Name = "panelConvertButton";
            this.panelConvertButton.Size = new System.Drawing.Size(554, 38);
            this.panelConvertButton.TabIndex = 71;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Top;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label9.Location = new System.Drawing.Point(0, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(340, 17);
            this.label9.TabIndex = 42;
            this.label9.Text = "Free HiQPdf HTML to PDF Converter for .NET";
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(566, 10);
            this.panel1.TabIndex = 43;
            // 
            // label16
            // 
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Location = new System.Drawing.Point(0, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(566, 54);
            this.label16.TabIndex = 44;
            this.label16.Text = resources.GetString("label16.Text");
            // 
            // ConvertHtmlToPdf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.Controls.Add(this.panelConvertButton);
            this.Controls.Add(this.panelSettings);
            this.Controls.Add(this.panelEnterHtmlCode);
            this.Controls.Add(this.panelEnterUrl);
            this.Controls.Add(this.panelSelectHtmlInput);
            this.Controls.Add(this.rightPanel);
            this.Controls.Add(this.leftPanel);
            this.Controls.Add(this.bottomPanel);
            this.Controls.Add(this.topPanel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.Name = "ConvertHtmlToPdf";
            this.Size = new System.Drawing.Size(566, 671);
            this.Load += new System.EventHandler(this.ConvertUrlToPdf_Load);
            this.topPanel.ResumeLayout(false);
            this.topPanel.PerformLayout();
            this.panelSelectHtmlInput.ResumeLayout(false);
            this.panelSelectHtmlInput.PerformLayout();
            this.panelEnterUrl.ResumeLayout(false);
            this.panelEnterUrl.PerformLayout();
            this.panelEnterHtmlCode.ResumeLayout(false);
            this.panelEnterHtmlCode.PerformLayout();
            this.panelSettings.ResumeLayout(false);
            this.panelSettings.PerformLayout();
            this.panelConvertButton.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel topPanel;
        private System.Windows.Forms.Panel bottomPanel;
        private System.Windows.Forms.Panel leftPanel;
        private System.Windows.Forms.Panel rightPanel;
        private System.Windows.Forms.Button buttonConvertToPdf;
        private System.Windows.Forms.ComboBox comboBoxPageOrientation;
        private System.Windows.Forms.ComboBox comboBoxPageSize;
        private System.Windows.Forms.TextBox textBoxBrowserWidth;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxUrl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblUrlField;
        private System.Windows.Forms.Panel panelSelectHtmlInput;
        private System.Windows.Forms.RadioButton radioButtonConvertHtmlCode;
        private System.Windows.Forms.RadioButton radioButtonConvertUrl;
        private System.Windows.Forms.Panel panelEnterUrl;
        private System.Windows.Forms.Panel panelEnterHtmlCode;
        private System.Windows.Forms.TextBox textBoxHtmlCode;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panelSettings;
        private System.Windows.Forms.Panel panelConvertButton;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxBaseUrl;
        private System.Windows.Forms.Panel panelSeparator;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel;
        private System.Windows.Forms.Panel panelMargin;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBoxLoadHtmlTimeout;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxWaitTime;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxBrowserHeight;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label9;

    }
}
