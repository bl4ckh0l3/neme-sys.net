﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;

using HiQPdf;

namespace HiQPdf_Demo
{
    public partial class ConvertHtmlToPdf : UserControl
    {
        public ConvertHtmlToPdf()
        {
            InitializeComponent();
        }

        private void buttonConvertToPdf_Click(object sender, EventArgs e)
        {
            // create the HTML to PDF converter
            HtmlToPdf htmlToPdfConverter = new HtmlToPdf();

            // set browser width
            htmlToPdfConverter.BrowserWidth = int.Parse(textBoxBrowserWidth.Text);

            // set browser height if specified, otherwise use the default
            if (textBoxBrowserHeight.Text.Length > 0)
                htmlToPdfConverter.BrowserHeight = int.Parse(textBoxBrowserHeight.Text);

            // set HTML Load timeout
            htmlToPdfConverter.HtmlLoadedTimeout = int.Parse(textBoxLoadHtmlTimeout.Text);

            // set PDF page size and orientation
            htmlToPdfConverter.Document.PageSize = GetSelectedPageSize();
            htmlToPdfConverter.Document.PageOrientation = GetSelectedPageOrientation();
            
            // set PDF page margins
            htmlToPdfConverter.Document.Margins = new PdfMargins(0);

            // set a wait time before starting the conversion
            htmlToPdfConverter.WaitBeforeConvert = int.Parse(textBoxWaitTime.Text);

            Cursor = Cursors.WaitCursor;

            // convert HTML to PDF
            string pdfFile = null;
            try
            {
                if (radioButtonConvertUrl.Checked)
                {
                    // convert URL
                    string url = textBoxUrl.Text;
                    pdfFile = Application.StartupPath + @"\DemoOut\ConvertUrl.pdf";

                    // ConvertUrlToFile() is called to convert the html document and save the resulted PDF into a file on disk
                    // Alternatively, ConvertUrlToMemory() can be called to save the resulted PDF in a buffer in memory
                    htmlToPdfConverter.ConvertUrlToFile(url, pdfFile);
                }
                else
                {
                    // convert HTML code
                    string htmlCode = textBoxHtmlCode.Text;
                    string baseUrl = textBoxBaseUrl.Text;
                    pdfFile = Application.StartupPath + @"\DemoOut\ConvertHtml.pdf";

                    htmlToPdfConverter.ConvertHtmlToFile(htmlCode, baseUrl, pdfFile);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(String.Format("Conversion failed. {0}", ex.Message));
                return;
            }
            finally
            {
                Cursor = Cursors.Arrow;
            }

            // open the PDF document
            try
            {
                System.Diagnostics.Process.Start(pdfFile);
            }
            catch (Exception ex)
            {
                MessageBox.Show(String.Format("Conversion succeeded but cannot open '{0}'. {1}", pdfFile, ex.Message));
            }
        }

        private PdfPageSize GetSelectedPageSize()
        {
            switch (comboBoxPageSize.SelectedItem.ToString())
            {
                case "A0":
                    return PdfPageSize.A0;
                case "A1":
                    return PdfPageSize.A1;
                case "A10":
                    return PdfPageSize.A10;
                case "A2":
                    return PdfPageSize.A2;
                case "A3":
                    return PdfPageSize.A3;
                case "A4":
                    return PdfPageSize.A4;
                case "A5":
                    return PdfPageSize.A5;
                case "A6":
                    return PdfPageSize.A6;
                case "A7":
                    return PdfPageSize.A7;
                case "A8":
                    return PdfPageSize.A8;
                case "A9":
                    return PdfPageSize.A9;
                case "ArchA":
                    return PdfPageSize.ArchA;
                case "ArchB":
                    return PdfPageSize.ArchB;
                case "ArchC":
                    return PdfPageSize.ArchC;
                case "ArchD":
                    return PdfPageSize.ArchD;
                case "ArchE":
                    return PdfPageSize.ArchE;
                case "B0":
                    return PdfPageSize.B0;
                case "B1":
                    return PdfPageSize.B1;
                case "B2":
                    return PdfPageSize.B2;
                case "B3":
                    return PdfPageSize.B3;
                case "B4":
                    return PdfPageSize.B4;
                case "B5":
                    return PdfPageSize.B5;
                case "Flsa":
                    return PdfPageSize.Flsa;
                case "HalfLetter":
                    return PdfPageSize.HalfLetter;
                case "Ledger":
                    return PdfPageSize.Ledger;
                case "Legal":
                    return PdfPageSize.Legal;
                case "Letter":
                    return PdfPageSize.Letter;
                case "Letter11x17":
                    return PdfPageSize.Letter11x17;
                case "Note":
                    return PdfPageSize.Note;
                default:
                    return PdfPageSize.A4;
            }
        }

        private PdfPageOrientation GetSelectedPageOrientation()
        {
            return (comboBoxPageOrientation.SelectedItem.ToString() == "Portrait")?
                PdfPageOrientation.Portrait : PdfPageOrientation.Landscape;
        }

        private void ConvertUrlToPdf_Load(object sender, EventArgs e)
        {
            comboBoxPageOrientation.SelectedItem = "Portrait";
            comboBoxPageSize.SelectedItem = "A4";

            panelEnterUrl.Visible = radioButtonConvertUrl.Checked;
            panelEnterHtmlCode.Visible = !radioButtonConvertUrl.Checked;
        }

        private void radioButtonConvertUrl_CheckedChanged(object sender, EventArgs e)
        {
            panelEnterUrl.Visible = radioButtonConvertUrl.Checked;
            panelEnterHtmlCode.Visible = !radioButtonConvertUrl.Checked;
        }

        private void radioButtonConvertHtmlCode_CheckedChanged(object sender, EventArgs e)
        {
            panelEnterUrl.Visible = radioButtonConvertUrl.Checked;
            panelEnterHtmlCode.Visible = !radioButtonConvertUrl.Checked;
        }
    }
}
