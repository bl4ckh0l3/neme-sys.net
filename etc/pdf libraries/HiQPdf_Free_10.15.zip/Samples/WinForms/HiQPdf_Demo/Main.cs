using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace HiQPdf_Demo
{
    public partial class Main : Form
    {
        private UserControl displayedControl = null;

        public Main()
        {
            InitializeComponent();
        }

        private void DisplayDemoForm(string demoName)
        {
            if (demoName == "htmlToPdfNode")
            {
                treeView.SelectedNode = treeView.Nodes["htmlToPdfNode"].Nodes["htmlToPdf"];
                return;
            }

            if (displayedControl != null)
            {
                splitContainer.Panel2.Controls.Remove(displayedControl);
                displayedControl.Dispose();
                displayedControl = null;
            }

            switch (demoName)
            {
                case "htmlToPdf":               
                    displayedControl = new ConvertHtmlToPdf();
                    break;
                case "FullHiQPdfLibrary":
                    displayedControl = new FullHiQPdfLibrary();
                    break;
            }

            if (displayedControl != null)
            {
                displayedControl.Dock = DockStyle.Fill;
                displayedControl.BorderStyle = BorderStyle.FixedSingle;
                splitContainer.Panel2.Controls.Add(displayedControl);
            }
        }

        private void treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (treeView.SelectedNode == null)
                return;
            if (treeView.SelectedNode.Name == null)
                return;

            DisplayDemoForm(treeView.SelectedNode.Name);
        }

        private void treeView_BeforeSelect(object sender, TreeViewCancelEventArgs e)
        {
        }

        private void Main_Load(object sender, EventArgs e)
        {
            treeView.ExpandAll();

            treeView.SelectedNode = treeView.Nodes["htmlToPdfNode"].Nodes["htmlToPdf"];
        }
    }
}